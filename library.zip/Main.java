import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private String isbn;

    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }
}

class FictionBook extends Book {
    private String genre;

    public FictionBook(String title, String author, String isbn, String genre) {
        super(title, author, isbn);
        this.genre = genre;
    }

    public String getGenre() {
        return genre;
    }
}

class NonFictionBook extends Book {
    private String subject;

    public NonFictionBook(String title, String author, String isbn, String subject) {
        super(title, author, isbn);
        this.subject = subject;
    }

    public String getSubject() {
        return subject;
    }
}

class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void showAvailableBooks() {
        if (books.isEmpty()) {
            System.out.println("No books available in the library.");
        } else {
            System.out.println("Available books in the library:");
            for (Book book : books) {
                System.out.println("Title: " + book.getTitle() + ", Author: " + book.getAuthor() +
                        ", ISBN: " + book.getIsbn());
            }
        }
    }

    public void borrowBook(String isbn) {
        boolean found = false;
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                System.out.println("Book with ISBN " + isbn + " is borrowed.");
                books.remove(book);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Book with ISBN " + isbn + " is not available in the library.");
        }
    }

    public void returnBook(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                System.out.println("Book with ISBN " + isbn + " is returned.");
                books.add(book);
                return;
            }
        }
        System.out.println("Book with ISBN " + isbn + " is not valid for return.");
    }
}

public class Main {
    private static Library library = new Library();
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        runLibrarySystem();
    }

    public static void runLibrarySystem() {
        int choice;

        while (true) {
            System.out.println("1. Add a Book");
            System.out.println("2. Show Available Books");
            System.out.println("3. Borrow a Book");
            System.out.println("4. Return a Book");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();
            input.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    library.showAvailableBooks();
                    break;
                case 3:
                    borrowBook();
                    break;
                case 4:
                    returnBook();
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Invalid option");
            }
        }
    }

    public static void addBook() {
        System.out.print("Enter book title: ");
        String title = input.nextLine();

        System.out.print("Enter author: ");
        String author = input.nextLine();

        System.out.print("Enter ISBN: ");
        String isbn = input.nextLine();

        System.out.print("Book type (Fiction/NonFiction): ");
        String type = input.nextLine();

        Book book;

        if (type.equalsIgnoreCase("Fiction")) {
            System.out.print("Enter genre: ");
            String genre = input.nextLine();

            book = new FictionBook(title, author, isbn, genre);
        } else {
            System.out.print("Enter subject: ");
            String subject = input.nextLine();

            book = new NonFictionBook(title, author, isbn, subject);
        }

        library.addBook(book);

        System.out.println("New book added successfully!");
    } 
       
    

    public static void borrowBook() {
        System.out.print("Enter ISBN of book to borrow: ");
        String isbn = input.nextLine();
        library.borrowBook(isbn);
    }

    public static void returnBook() {
        System.out.print("Enter ISBN of book to return: ");
        String isbn = input.nextLine();
        library.returnBook(isbn);
    }
}
