import java.util.*;

//create book class
class Book {
private String title;
private String author;
private String isbn;
private boolean isAvailable;

public Book(String title, String author, String isbn, boolean isAvailable) {
this.title = title;
this.author = author;
this.isbn = isbn;
this.isAvailable = isAvailable;
}
// getters and setters
public String getTitle() {
return title;
}

public String getAuthor() {
return author;
}

public String getIsbn() {
return isbn;
}

public boolean isAvailable() {
return isAvailable;
}

public void setAvailable(boolean isAvailable) {
this.isAvailable = isAvailable;
}
}

//create Library class
class Library {
private ArrayList<Book> books = new ArrayList<>();

//to add a new book
public void addBook(Book book) {
books.add(book);
}

//display available books in the list
public void displayAvailableBooks() {
System.out.println("Available books:");
for (Book book : books) {
if (book.isAvailable()) {
System.out.println(book.getTitle() + " by " + book.getAuthor() + " (ISBN: " + book.getIsbn() + ")");
}
}
}

//Borrow a book from Library
public void borrowBook(String isbn) {
for (Book book : books) {
if (book.getIsbn().equals(isbn)) {
if (book.isAvailable()) {
book.setAvailable(false);
System.out.println("You have borrowed the book: " + book.getTitle());
} else {
System.out.println("The book is not available for borrowing.");
}
return;
}
}
System.out.println("The book with ISBN " + isbn + " is not found.");
}

//Return a book
public void returnBook(String isbn) {
for (Book book : books) {
if (book.getIsbn().equals(isbn)) {
book.setAvailable(true);
System.out.println("You have returned the book: " + book.getTitle());
return;
}
}
System.out.println("The book with ISBN " + isbn + " is not found.");
}
}

//create user class
class User {
private String id;
private ArrayList<Book> borrowedBooks = new ArrayList<>();

public User(String id) {
this.id = id;
}

//Getters and Setters user class
public String getId() {
return id;
}

public ArrayList<Book> getBorrowedBooks() {
return borrowedBooks;
}

public void borrowBook(Book book) {
borrowedBooks.add(book);
}

public void returnBook(Book book) {
borrowedBooks.remove(book);
}
}

//Inheritance
class FictionBook extends Book {
public FictionBook(String title, String author, String isbn, boolean isAvailable) {
super(title, author, isbn, isAvailable);
}
}

class NonFictionBook extends Book {
public NonFictionBook(String title, String author, String isbn, boolean isAvailable) {
super(title, author, isbn, isAvailable);
}
}

//Create Main class
public class LibraryManagementSystem {
public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);
Library library = new Library();
User user = new User(UUID.randomUUID().toString());

//Main menu
while (true) {
System.out.println("|___ Welcome to the Royal Library Management System ___|");
System.out.println("Please select an option:");
System.out.println("1. Add a new book");
System.out.println("2. Display available books");
System.out.println("3. Borrow a book");
System.out.println("4. Return a book");
System.out.println("5. Exit");

int option = scanner.nextInt();
scanner.nextLine();

switch (option) {
case 1:
// to add a new book
System.out.println("Enter the title of the book:");
String title = scanner.nextLine();
System.out.println("Enter the author of the book:");
String author = scanner.nextLine();
System.out.println("Enter the ISBN of the book:");
String isbn = scanner.nextLine();
Book newBook = new Book(title, author, isbn, true);
library.addBook(newBook);
System.out.println("The book added to the library.");
break;
case 2:
//Display available Books
library.displayAvailableBooks();
break;
case 3:
//Borrow a book from list
System.out.println("Enter the ISBN of the book you want to borrow:");
String borrowIsbn = scanner.nextLine();
library.borrowBook(borrowIsbn);
break;
case 4:
//return a book
System.out.println("Enter the ISBN of the book you want to return:");
String returnIsbn = scanner.nextLine();
library.returnBook(returnIsbn);
break;
case 5:
//Exit
System.out.println("Thank you for using the Royal Library Management System!");
return;
default:
System.out.println("Invalid option. Please try again.");
break;
}
}
}
}