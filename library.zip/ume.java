import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Base class representing a book
class Book {
    private String title;
    private String author;
    private String isbn;
    private boolean available;

    public Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.available = true;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Author: " + author + ", ISBN: " + isbn + ", Available: " + available;
    }
}

// Inherited class for fiction books
class FictionBook extends Book {
    public FictionBook(String title, String author, String isbn) {
        super(title, author, isbn);
    }
}

// Inherited class for non-fiction books
class NonFictionBook extends Book {
    public NonFictionBook(String title, String author, String isbn) {
        super(title, author, isbn);
    }
}

// Class representing a library
class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    // Function to add a new book to the library
    public void addBook(Book book) {
        books.add(book);
    }

    // Function to display available books
    public void displayAvailableBooks() {
        System.out.println("Available Books:");
        for (Book book : books) {
            if (book.isAvailable()) {
                System.out.println(book);
            }
        }
    }

    // Function to borrow a book
    public void borrowBook(User user, String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn) && book.isAvailable()) {
                book.setAvailable(false);
                user.borrowBook(book);
                System.out.println("Book borrowed successfully!");
                return;
            }
        }
        System.out.println("Book not available for borrowing.");
    }

    // Function to return a book
    public void returnBook(User user, String isbn) {
        for (Book book : user.getBorrowedBooks()) {
            if (book.getIsbn().equals(isbn)) {
                book.setAvailable(true);
                user.returnBook(book);
                System.out.println("Book returned successfully!");
                return;
            }
        }
        System.out.println("Book not found in the user's borrowed books.");
    }
}

// Class representing a library user
class User {
    private static int userIdCounter = 1;
    private int userId;
    private List<Book> borrowedBooks;

    public User() {
        this.userId = userIdCounter++;
        this.borrowedBooks = new ArrayList<>();
    }

    // Function to borrow a book
    public void borrowBook(Book book) {
        borrowedBooks.add(book);
    }

    // Function to return a book
    public void returnBook(Book book) {
        borrowedBooks.remove(book);
    }

    // Function to get the list of borrowed books
    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    @Override
    public String toString() {
        return "User ID: " + userId;
    }
}

// Class representing the addition of a new book
class AddNewBook {
    public static Book createNewBook() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the title of the new book: ");
        String title = scanner.nextLine();
        System.out.print("Enter the author of the new book: ");
        String author = scanner.nextLine();
        System.out.print("Enter the ISBN of the new book: ");
        String isbn = scanner.nextLine();

        // You can add more logic here if you want to distinguish between Fiction and NonFiction books
        return new Book(title, author, isbn);
    }
}

// Main class for the Library Management System
public class LibraryManagementSystem {
    public static void main(String[] args) {
        Library library = new Library();
        User user = new User();

        Book fictionBook = new FictionBook("Fiction Book 1", "Author 1", "123-456-789");
        Book nonFictionBook = new NonFictionBook("Non-Fiction Book 1", "Author 2", "987-654-321");

        library.addBook(fictionBook);
        library.addBook(nonFictionBook);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Display Available Books");
            System.out.println("2. Borrow a Book");
            System.out.println("3. Return a Book");
            System.out.println("4. Add New Book");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (choice) {
                case 1:
                    library.displayAvailableBooks();
                    break;
                case 2:
                    System.out.print("Enter the ISBN of the book to borrow: ");
                    String borrowIsbn = scanner.nextLine();
                    library.borrowBook(user, borrowIsbn);
                    break;
                case 3:
                    System.out.print("Enter the ISBN of the book to return: ");
                    String returnIsbn = scanner.nextLine();
                    library.returnBook(user, returnIsbn);
                    break;
                case 4:
                    Book newBook = AddNewBook.createNewBook();
                    library.addBook(newBook);
                    System.out.println("New book added successfully!");
                    break;
                case 5:
                    System.out.println("Exiting the Library Management System. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
